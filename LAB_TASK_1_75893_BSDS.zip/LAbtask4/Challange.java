/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LAbtask4;

/**
 *
 * @author hp
 */
class BankAccount {
    String accountHolderName;
    double balance;

    public BankAccount(String accountHolderName, double balance) {
        this.accountHolderName = accountHolderName;
        this.balance = balance;
    }

    public double getBalance() {
        return balance;
    }

    public void deposit(double amount) {
        balance += amount;
    }

    public void withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
            System.out.println("Withdrawal successful.");
        } else {
            System.out.println("Insufficient balance.");
        }
    }
}

public class Challange{
    public static void main(String[] args) {
        BankAccount account = new BankAccount("Bilal", 5000);

        System.out.println("Account Holder: " + account.accountHolderName);
        System.out.println("Balance: " + account.getBalance());

        account.deposit(2000);
        System.out.println("After Deposit: " + account.getBalance());

        account.withdraw(3000);
        System.out.println("After Withdrawal: " + account.getBalance());

        account.withdraw(5000);
        System.out.println("Final Balance: " + account.getBalance());
    }
}