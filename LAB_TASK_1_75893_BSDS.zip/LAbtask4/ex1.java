/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LAbtask4;

/**
 *
 * @author hp
 */
class Book {
   
    String title;
    String author;
    double price;

    
    public Book(String title, String author, double price) {
        this.title = title;
        this.author = author;
        this.price = price;
    }

    public void displayBook() {
        System.out.println("Title: " + title);
        System.out.println("Author: " + author);
        System.out.println("Price: $" + price);
    }

 
    public void updatePrice(double newPrice) {
        price = newPrice;
    }
}

class Rectangle {
  
    double width;
    double height;

    public Rectangle(double width, double height) {
        this.width = width;
        this.height = height;
    }

    public double area() {
        return width * height;
    }

    
    public double perimeter() {
        return 2 * (width + height);
    }
}

public class ex1 {
    public static void main(String[] args) {

        
        Book book1 = new Book("Java Programming", "James Gosling", 25.50);
        Book book2 = new Book("Data Science Basics", "John Smith", 30.00);

        System.out.println("===== BOOK 1 =====");
        book1.displayBook();

        System.out.println("\n===== BOOK 2 =====");
        book2.displayBook();

      
        System.out.println("\n===== AFTER UPDATING BOOK 1 PRICE =====");
        book1.updatePrice(28.50);

        book1.displayBook();

      
        System.out.println("\n===== BOOK 2 REMAINS UNCHANGED =====");
        book2.displayBook();

  
        Rectangle rectangle = new Rectangle(10, 5);

        System.out.println("\n===== RECTANGLE =====");
        System.out.println("Width: " + rectangle.width);
        System.out.println("Height: " + rectangle.height);
        System.out.println("Area: " + rectangle.area());
        System.out.println("Perimeter: " + rectangle.perimeter());
    }
}