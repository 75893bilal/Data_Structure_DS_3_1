/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LAbtask4;

/**
 *
 * @author hp
 */
class Counter {

    private int count;

    public Counter() {
        count = 0;
    }

    public int getCount() {
        return count;
    }

    public void increment() {
        count++;
    }
}

public class Activity2 {

    public static void main(String[] args) {

        Counter c = new Counter();

        c.increment();
        c.increment();

        System.out.println(c.getCount());
    }
}