/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LAbtask5;

/**
 *
 * @author hp
 */
public class ex4 {
    
    public static void main(String[] args) {
        double number = 9.8;

        int result = (int) number;

        System.out.println("Double: " + number);
        System.out.println("Integer: " + result);
    }
}
    

