/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LAbtask5;

/**
 *
 * @author hp
 */
public class Activity1 {
  
    public static void main(String[] args) {
        int a = 7;
        int b = 2;

        System.out.println(a / b);
        System.out.println((double) a / b);
    }
}
    
