/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LAbtask5;

/**
 *
 * @author hp
 */
public class a4 {
  
    public static void main(String[] args) {
        double d = 9.8;
        int x = (int) d;
        double y = 10;

        System.out.println(x);
        System.out.println(y);
    }
}

