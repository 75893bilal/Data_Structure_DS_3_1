/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LAbtask5;

/**
 *
 * @author hp
 */
public class a3 {
    public static void main(String[] args) {
        int age = 20;
        boolean hasCard = true;

        System.out.println(age >= 18 && hasCard);
        System.out.println(age >= 18 || hasCard);
    }
}
    
