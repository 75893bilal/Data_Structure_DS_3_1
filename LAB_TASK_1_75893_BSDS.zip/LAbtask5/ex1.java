/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LAbtask5;

/**
 *
 * @author hp
 */
public class ex1
{
    public static void main(String[] args) {
        int a = 10;
        int b = 20;
        int c = 25;

        double average = (a + b + c) / 3.0;

        System.out.println("Average: " + average);
    }
}