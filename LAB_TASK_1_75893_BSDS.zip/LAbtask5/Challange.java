/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LAbtask5;

/**
 *
 * @author hp
 */
  import java.util.Scanner;

public class Challange {
  

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter first mark: ");
        double mark1 = input.nextDouble();

        System.out.print("Enter second mark: ");
        double mark2 = input.nextDouble();

        System.out.print("Enter third mark: ");
        double mark3 = input.nextDouble();

        double average = (mark1 + mark2 + mark3) / 3.0;

        boolean pass = average >= 50 && mark1 >= 40 && mark2 >= 40 && mark3 >= 40;

        System.out.println("Average: " + average);
        System.out.println("Pass: " + pass);

        input.close();
    }
}
    

