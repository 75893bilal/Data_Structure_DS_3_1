package com.mycompany.labtask1;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author hp
 */
public class ex3 {
     public static void main(String[] args) {

        String studentName = "Bilal";
        int studentAge = 20;
        int semesterNumber = 2;
        double studentCGPA = 3.25;
        String studentDepartment = "Data Science";

        System.out.println("Student Name: " + studentName);
        System.out.println("Student Age: " + studentAge);
        System.out.println("Semester Number: " + semesterNumber);
        System.out.println("Student CGPA: " + studentCGPA);
        System.out.println("Student Department: " + studentDepartment);
    }
}
