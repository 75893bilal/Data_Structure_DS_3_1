/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.labtask1;

/**
 *
 * @author hp
 */
public class Activity3 {
        public static void main(String[] args) {

    int x = 10;
x = x + 5;
x++;
System.out.println(x);
    
}
}
