/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.labtask1;

/**
 *
 * @author hp
 */
public class LABTask1 {

    public static void main(String[] args) {
        System.out.println("Welcome to Data Structures Lab");
    }
}
