/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.labtask1;

/**
 *
 * @author hp
 */
public class ex4 {
   
    public static void main(String[] args) {

        String studentname = "Bilal";

        System.out.println(studentname);
    }
}
    

