/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.labtask1;

/**
 *
 * @author hp
 */
public class ex1 {
   
    public static void main(String[] args) {

        String name = "Bilal";
        int semester = 2;
        double cgpa = 3.25;

        System.out.println("Name: " + name);
        System.out.println("Semester: " + semester);
        System.out.println("CGPA: " + cgpa);
    }
}
    

