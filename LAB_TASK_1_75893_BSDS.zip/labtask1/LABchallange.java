
package com.mycompany.labtask1;

/**
 *
 * @author hp
 */
public class LABchallange {
    
    public static void main(String[] args) {

        String studentName = "Bilal";
        int studentAge = 20;
        int semester = 2;
        double cgpa = 3.25;
        char grade = 'A';
        boolean passed = true;

        System.out.println(" Student Information");
        System.out.println("Student Name: " + studentName);
        System.out.println("Age: " + studentAge);
        System.out.println("Semester: " + semester);
        System.out.println("CGPA: " + cgpa);
        System.out.println("Grade: " + grade);
        System.out.println("Passed: " + passed);
    }
}
    


