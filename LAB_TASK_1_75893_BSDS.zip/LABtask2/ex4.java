/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.labtask1.LABtask2;
   import java.util.Scanner;
/**
 *
 * @author hp
 */
public class ex4 {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter your choice (1-3): ");
        int choice = input.nextInt();

        switch (choice) {
            case 1:
                System.out.println("Insert");

            case 2:
                System.out.println("Delete");
                break;

            case 3:
                System.out.println("Update");
                break;

            default:
                System.out.println("Invalid choice");
        }
    }
}

