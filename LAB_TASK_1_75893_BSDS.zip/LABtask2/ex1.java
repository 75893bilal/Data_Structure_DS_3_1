/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.labtask1.LABtask2;
import java.util.Scanner;
/**
 *
 * @author hp
 */
public class ex1 {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter first integer: ");
        int num1 = input.nextInt();

        System.out.print("Enter second integer: ");
        int num2 = input.nextInt();

        if (num1 > num2)
            System.out.println("Larger value = " + num1);
        else if (num2 > num1)
            System.out.println("Larger value = " + num2);
        else
            System.out.println("Both values are equal");
    }
}

