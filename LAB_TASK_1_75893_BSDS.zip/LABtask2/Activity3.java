/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.labtask1.LABtask2;
 import java.util.Scanner;
/**
 *
 * @author hp
 */
public class Activity3 {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.println("1. Insert");
        System.out.println("2. Delete");
        System.out.print("Enter your choice: ");

        int choice = input.nextInt();

        switch (choice) {
            case 1:
                System.out.println("Insert");
                break;

            case 2:
                System.out.println("Delete");
                break;

            default:
                System.out.println("Invalid choice");
        }
    }
}
    
