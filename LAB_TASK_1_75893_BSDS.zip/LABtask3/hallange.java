/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.labtask1.LABtask3;

/**
 *
 * @author hp
 */
 import java.util.Scanner;
public class hallange {
   
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter number of courses: ");
        int n = input.nextInt();

        int[] marks = new int[n];

        // Input marks
        for (int i = 0; i < n; i++) {
            System.out.print("Enter marks for course " + (i + 1) + ": ");
            marks[i] = input.nextInt();
        }

        // Calculate sum and maximum
        int sum = 0;
        int maximum = marks[0];

        for (int mark : marks) {
            sum += mark;

            if (mark > maximum) {
                maximum = mark;
            }
        }

        // Count marks at least 50
        int passed = 0;

        for (int mark : marks) {
            if (mark >= 50) {
                passed++;
            }
        }

        System.out.println("\n Result ");
        System.out.println("Sum of marks = " + sum);
        System.out.println("Maximum marks = " + maximum);
        System.out.println("Marks at least 50 = " + passed);
    }
}

