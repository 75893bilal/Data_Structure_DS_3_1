/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.labtask1.LABtask3;

/**
 *
 * @author hp
 */
public class ex5 {

    public static void main(String[] args) {

        for (int i = 1; i <= 20; i++) {

            if (i % 3 == 0)
                continue;

            System.out.println(i);
        }
    }
}
    

