/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.labtask1.LABtask3;

/**
 *
 * @author hp
 */
public class Activity5 {
   
    public static void main(String[] args) {

        for (int i = 1; i <= 10; i++) {

            if (i == 5)
                continue;

            if (i == 9)
                break;

            System.out.println(i);
        }
    }
}
    

