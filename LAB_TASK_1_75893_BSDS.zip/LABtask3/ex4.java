/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.labtask1.LABtask3;

/**
 *
 * @author hp
 */
public class ex4 {
   
    public static void main(String[] args) {

        int[] numbers = {10, 25, 7, 40, 15};

        int maximum = numbers[0];

        for (int number : numbers) {

            if (number > maximum) {
                maximum = number;
            }
        }

        System.out.println("Maximum value = " + maximum);
    }
}
    

