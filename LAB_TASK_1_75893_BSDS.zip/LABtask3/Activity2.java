/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.labtask1.LABtask3;

/**
 *
 * @author hp
 */
public class Activity2 {
    
    public static void main(String[] args) {

        int i = 1;

        do {
            System.out.println(i);
            i++;

        } while (i <= 5);
    }
}

