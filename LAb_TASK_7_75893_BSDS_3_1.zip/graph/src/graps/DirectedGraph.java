/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package graps;

/**
 *
 * @author hp
 */

public class DirectedGraph {
    public static void main(String[] args) {
        int vertices = 5;
        int[][] graph = new int[vertices][vertices];
        // Add directed edges
        graph[0][1] = 1;
        graph[0][2] = 1;
        graph[1][2] = 1;
        graph[2][3] = 1;
        graph[3][1] = 1;
        // Display adjacency matrix
        System.out.println("Adjacency Matrix:");
        System.out.print("   ");
        for (int i = 0; i < vertices; i++) {
            System.out.print(i + " ");
        }
        System.out.println();
        for (int i = 0; i < vertices; i++) {
            System.out.print(i + "  ");
            for (int j = 0; j < vertices; j++) {
                System.out.print(graph[i][j] + " ");
            }
            System.out.println();
        }
        // Calculate in-degree and out-degree
        System.out.println("\nVertex Degrees:");
        for (int i = 0; i < vertices; i++) {
            int inDegree = 0;
            int outDegree = 0;
            // Calculate out-degree (sum of row)
            for (int j = 0; j < vertices; j++) {
                outDegree += graph[i][j];
            }
            // Calculate in-degree (sum of column)
            for (int j = 0; j < vertices; j++) {
                inDegree += graph[j][i];
            }
            System.out.println("Vertex " + i
                    + " - In-degree: " + inDegree
                    + ", Out-degree: " + outDegree);
        }
    }
}
