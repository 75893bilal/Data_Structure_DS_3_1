/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package graps;

/**
 *
 * @author hp
 */

import java.util.Scanner;

public class undirectedgraphmenue {

    static int vertices = 5;
    static int[][] graph = new int[vertices][vertices];

    // Add an edge
    public static void addEdge(int u, int v) {
        graph[u][v] = 1;
        graph[v][u] = 1;
        System.out.println("Edge added successfully.");
    }

    // Remove an edge
    public static void removeEdge(int u, int v) {
        if (graph[u][v] == 1) {
            graph[u][v] = 0;
            graph[v][u] = 0;
            System.out.println("Edge removed successfully.");
        } else {
            System.out.println("Edge does not exist.");
        }
    }

    // Display adjacency matrix
    public static void displayMatrix() {
        System.out.println("\nAdjacency Matrix:");

        System.out.print("   ");
        for (int i = 0; i < vertices; i++) {
            System.out.print(i + " ");
        }
        System.out.println();

        for (int i = 0; i < vertices; i++) {
            System.out.print(i + "  ");

            for (int j = 0; j < vertices; j++) {
                System.out.print(graph[i][j] + " ");
            }
            System.out.println();
        }
    }

    // Calculate degree of a vertex
    public static void calculateDegree(int v) {
        int degree = 0;

        for (int i = 0; i < vertices; i++) {
            degree += graph[v][i];
        }

        System.out.println("Degree of vertex " + v + ": " + degree);
    }

    // Check whether an edge exists
    public static void checkEdge(int u, int v) {
        if (graph[u][v] == 1) {
            System.out.println("Edge exists between " + u + " and " + v);
        } else {
            System.out.println("No edge exists between " + u + " and " + v);
        }
    }

    // Main method
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Create the initial graph
        addEdge(0, 1);
        addEdge(0, 2);
        addEdge(1, 2);
        addEdge(1, 3);
        addEdge(3, 4);

        int choice, u, v;

        do {
            System.out.println("\n===== UNDIRECTED GRAPH MENU =====");
            System.out.println("1. Add Edge");
            System.out.println("2. Remove Edge");
            System.out.println("3. Display Adjacency Matrix");
            System.out.println("4. Calculate Vertex Degree");
            System.out.println("5. Check Edge");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            choice = input.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter first vertex (0-4): ");
                    u = input.nextInt();
                    System.out.print("Enter second vertex (0-4): ");
                    v = input.nextInt();

                    if (u >= 0 && u < vertices &&
                        v >= 0 && v < vertices && u != v) {
                        addEdge(u, v);
                    } else {
                        System.out.println("Invalid vertices.");
                    }
                    break;

                case 2:
                    System.out.print("Enter first vertex (0-4): ");
                    u = input.nextInt();
                    System.out.print("Enter second vertex (0-4): ");
                    v = input.nextInt();

                    if (u >= 0 && u < vertices &&
                        v >= 0 && v < vertices && u != v) {
                        removeEdge(u, v);
                    } else {
                        System.out.println("Invalid vertices.");
                    }
                    break;

                case 3:
                    displayMatrix();
                    break;

                case 4:
                    System.out.print("Enter vertex (0-4): ");
                    v = input.nextInt();

                    if (v >= 0 && v < vertices) {
                        calculateDegree(v);
                    } else {
                        System.out.println("Invalid vertex.");
                    }
                    break;

                case 5:
                    System.out.print("Enter first vertex (0-4): ");
                    u = input.nextInt();
                    System.out.print("Enter second vertex (0-4): ");
                    v = input.nextInt();

                    if (u >= 0 && u < vertices &&
                        v >= 0 && v < vertices && u != v) {
                        checkEdge(u, v);
                    } else {
                        System.out.println("Invalid vertices.");
                    }
                    break;

                case 6:
                    System.out.println("Program ended.");
                    break;

                default:
                    System.out.println("Invalid choice. Try again.");
            }

        } while (choice != 6);

        input.close();
    }
}
