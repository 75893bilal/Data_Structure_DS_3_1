/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package graps;

/**
 *
 * @author hp
 */

import java.util.Scanner;

public class Directedmenu {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        int vertices = 5;
        int[][] graph = new int[vertices][vertices];

        int choice, u, v;

        do {
            System.out.println("\n===== UNIVERSITY DEPARTMENT GRAPH =====");
            System.out.println("1. Enter Department Connections");
            System.out.println("2. Display Adjacency Matrix");
            System.out.println("3. Check Direct Connection");
            System.out.println("4. Display Department Degree");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            choice = input.nextInt();

            switch (choice) {

                case 1:
                    System.out.print("Enter first department (0-4): ");
                    u = input.nextInt();

                    System.out.print("Enter second department (0-4): ");
                    v = input.nextInt();

                    if (u >= 0 && u < vertices &&
                        v >= 0 && v < vertices && u != v) {

                        graph[u][v] = 1;
                        graph[v][u] = 1;

                        System.out.println("Connection added successfully.");

                    } else {
                        System.out.println("Invalid department numbers.");
                    }
                    break;

                case 2:
                    System.out.println("\nAdjacency Matrix:");

                    System.out.print("   ");
                    for (int i = 0; i < vertices; i++) {
                        System.out.print(i + " ");
                    }
                    System.out.println();

                    for (int i = 0; i < vertices; i++) {
                        System.out.print(i + "  ");

                        for (int j = 0; j < vertices; j++) {
                            System.out.print(graph[i][j] + " ");
                        }

                        System.out.println();
                    }
                    break;

                case 3:
                    System.out.print("Enter first department (0-4): ");
                    u = input.nextInt();

                    System.out.print("Enter second department (0-4): ");
                    v = input.nextInt();

                    if (u >= 0 && u < vertices &&
                        v >= 0 && v < vertices && u != v) {

                        if (graph[u][v] == 1) {
                            System.out.println("Departments " + u +
                                    " and " + v + " are directly connected.");
                        } else {
                            System.out.println("Departments " + u +
                                    " and " + v + " are not directly connected.");
                        }

                    } else {
                        System.out.println("Invalid department numbers.");
                    }
                    break;

                case 4:
                    System.out.print("Enter department number (0-4): ");
                    v = input.nextInt();

                    if (v >= 0 && v < vertices) {
                        int degree = 0;

                        for (int i = 0; i < vertices; i++) {
                            degree += graph[v][i];
                        }

                        System.out.println("Degree of department " +
                                v + ": " + degree);

                    } else {
                        System.out.println("Invalid department number.");
                    }
                    break;

                case 5:
                    System.out.println("Program ended.");
                    break;

                default:
                    System.out.println("Invalid choice. Try again.");
            }

        } while (choice != 5);

        input.close();
    }
}
