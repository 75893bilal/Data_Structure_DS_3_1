/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package graps;

/**
 *
 * @author hp
 */

public class undirectedgraph{
    public static void main(String[] args) {
        int vertices = 5;
        int[][] graph = new int[vertices][vertices];
        // Add edges
        addEdge(graph, 0, 1);
        addEdge(graph, 0, 2);
        addEdge(graph, 1, 2);
        addEdge(graph, 1, 3);
        addEdge(graph, 3, 4);
        // Display adjacency matrix
        System.out.println("Adjacency Matrix:");
        System.out.print("   ");
        for (int i = 0; i < vertices; i++) {
            System.out.print(i + " ");}
        System.out.println();
        for (int i = 0; i < vertices; i++) {
            System.out.print(i + "  ");
            for (int j = 0; j < vertices; j++) {
                System.out.print(graph[i][j] + " ");
            }
            System.out.println();
        }
        // Calculate degree of each vertex
        System.out.println("\nVertex Degrees:");

        for (int i = 0; i < vertices; i++) {
            int degree = 0;

            for (int j = 0; j < vertices; j++) {
                degree += graph[i][j];
            }
            System.out.println(
                "Degree of vertex " + i + ": " + degree
            );}}      
    public static void addEdge(int[][] graph, int u, int v) {
        graph[u][v] = 1;
        graph[v][u] = 1;
    }}

