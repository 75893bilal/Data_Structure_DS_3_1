/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication9;

/**
 *
 * @author hp
 */
import java.util.Scanner;
public class Linear_search {
    public static int linearSearch(int[] arr, int target) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) {
                return i;
            }
        }
        return -1;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] linearArray = {45, 12, 78, 34, 23, 89, 56};
        System.out.print("Enter target value: ");
        int target = sc.nextInt();
        int result = linearSearch(linearArray, target);
        System.out.println("Target value: " + target);
        if (result != -1) {
            System.out.println("Linear Search: Element found");
            System.out.println("Index position: " + result);
        } else {
            System.out.println("Linear Search: Element not found");
            System.out.println("Index position: -1");
        }
        sc.close();
    }
}