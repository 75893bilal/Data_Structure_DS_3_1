/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication9;

/**
 *
 * @author hp
 */
public class Queue_operation {
    int[] queue = new int[5];
    int front = 0;
    int rear = -1;
    // Enqueue operation
    void enqueue(int value) {
        if (rear == 4) {
            System.out.println("Queue Overflow");
        } else {
            rear++;
            queue[rear] = value;
            System.out.println(value + " added to queue");
        }
    }
    // Dequeue operation
    void dequeue() {
        if (front > rear) {
            System.out.println("Queue Underflow");
        } else {
            System.out.println(queue[front] + " removed from queue");
            front++;
        }
    }

    // Peek operation
    void peek() {
        if (front > rear) {
            System.out.println("Queue is empty");
        } else {
            System.out.println("Front element: " + queue[front]);
        }
    }
    // Display operation
    void display() {
        if (front > rear) {
            System.out.println("Queue is empty");
        } else {
            System.out.println("Queue elements:");

            for (int i = front; i <= rear; i++) {
                System.out.println(queue[i]);
            }
        }
    }
    public static void main(String[] args) {
        Queue_operation q = new Queue_operation();
        // Demonstration
        q.enqueue(10);
        q.enqueue(20);
        q.enqueue(30);
        q.display();
        q.peek();
        q.dequeue();
        q.display();
    }
}
